avengers = ["thor", "ironman", "black widow", "captain"]
print("avengers =", avengers)
print("type of avengers =", type(avengers))
print("------")
      
avengers = ("thor", "ironman", "black widow", "captain")
print("avengers =", avengers)
print("type of avengers =", type(avengers))

#error
avengers[0] = "Thor"




