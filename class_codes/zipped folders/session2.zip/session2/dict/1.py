avengers = {"ironman", "captain", "hawkeye", "thor"}

avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}
print(type(avengers))

print(avengers["hawkeye"])
