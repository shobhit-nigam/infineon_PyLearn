avengers = {"ironman", "captain", "hawkeye", "thor"}

avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}
print(avengers)
print("-----");
avengers["ironman"] = "SUIT"
avengers["captain"] = ["hammer", "shield"]

print(avengers)

