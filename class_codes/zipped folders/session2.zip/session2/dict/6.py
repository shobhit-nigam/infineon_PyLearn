avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}


dc = ["batman", "wonder woman", "flash"]

heroes = {"dc_key":dc, "ave":avengers}


print(heroes.keys())
print("----")
print(heroes.values())

print(list(heroes.keys()))
