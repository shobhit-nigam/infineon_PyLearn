
print("hello world")

display = print

display("hello world")

print = 10

#error
print("hello")

