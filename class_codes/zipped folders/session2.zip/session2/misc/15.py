
seta = {3, 7, 10, 23, 0, 56}
lista = [False, 0.0, [ ], '', 0]
listb = [11, 34, 67, 10, 33]

print(any(seta))
print(any(lista))
print(all(seta))
print(all(listb))

