avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}


dc = ["batman", "wonder woman", "flash"]

print("flash" in dc)
