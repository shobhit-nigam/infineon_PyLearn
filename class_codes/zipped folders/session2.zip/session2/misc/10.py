#False

False   #bool
0       #value is zero
0.0     #value is zero
None    #NoneType

''



