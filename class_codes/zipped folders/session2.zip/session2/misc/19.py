
varx = 30

print(varx)

del varx

print(varx)
