lunch_a = {"chapati", "rice" , "dal", "mango", "rice", "chapati", "apple"}
lunch_b = {"rice" , "chapati", "pasta", "biryani"}

stra = "4589"
strb = "hello"

inta = int(stra)

print("type of stra =", type(stra))
print("type of inta =", type(inta))
