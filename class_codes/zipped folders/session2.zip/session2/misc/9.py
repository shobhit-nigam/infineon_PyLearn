#tuple
a = 10, 20, 30
b = 10    #int
c = 10,   #tuple
d = (12)  #int
e = (12,) #tuple
f = [ ]   #list
g = { }   #dict
e = set() #set



