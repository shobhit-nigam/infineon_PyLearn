#tuple
x, y, z = 10, 20, 30
x = y = z = 33
x = 10, 20, 30
print("x =", x)
print("type of x =", type(x))

#error 
x, y = 10, 20, 30
