
print("hello world")

display = print

display("hello world")

x = display

x("hello")

