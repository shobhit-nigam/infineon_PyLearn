
#i = eval(input("please enter whole numbers only\n"))

#print("i =", i)

#print("type of i =", type(i))

print(eval("4 + 10 * 2"))



