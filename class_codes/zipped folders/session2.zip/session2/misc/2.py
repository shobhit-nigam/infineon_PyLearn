lunch_a = {"chapati", "rice" , "dal", "mango", "rice", "chapati", "apple"}
lunch_b = ["rice" , "chapati", "pasta", "biryani"]


la = list(lunch_a)

print("type of stra =", type(lunch_a))
print("type of la =", type(la))


sb = set(lunch_b[1:3])
print("type of sb =", type(sb))
