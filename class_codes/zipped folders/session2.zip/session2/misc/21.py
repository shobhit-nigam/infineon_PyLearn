
lista = ["aa", "bb", "cc", "dd"]
print("lista =", lista)
# deletes the list
# del lista

del lista[1:3]

print("lista =", lista)
