
i = input()

print("i =", i)

print("type of i =", type(i))


