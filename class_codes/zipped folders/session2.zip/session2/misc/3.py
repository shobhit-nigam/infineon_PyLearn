stra = "I had chapati, rice and dal with mango"

ls = stra.split(',')

print(ls)
