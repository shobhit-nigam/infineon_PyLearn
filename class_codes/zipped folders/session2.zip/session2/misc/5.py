# operators 
avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}


dc = ["batman", "wonder woman", "flash"]
mar = ["mystique", "wolverine", "moon knight"]

print("hello" + "hi")
print("hello" + "hi"*3)

print(dc + mar)
