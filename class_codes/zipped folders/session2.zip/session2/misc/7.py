# operators 
avengers = {"ironman":"suit", "captain":"shield", "hawkeye":"arrow", "thor":"hammer"}


dc = ["batman", "wonder woman", "flash"]
mar = ["mystique", "wolverine", "moon knight"]

print("h" in "hello")
