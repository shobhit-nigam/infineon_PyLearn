lunch_a = {"chapati", "rice" , "dal", "mango", "rice", "chapati", "apple"}
lunch_b = {"rice" , "chapati", "pasta", "biryani"}

print(type(lunch_a))
print("lunch_a =", lunch_a)
print("lunch_b =", lunch_b)

#union
print("lunch_a | lunch_b =", lunch_a | lunch_b)

#intersection
print("lunch_a & lunch_b =", lunch_a & lunch_b)

