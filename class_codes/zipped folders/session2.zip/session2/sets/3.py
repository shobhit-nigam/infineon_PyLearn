lunch_a = {"chapati", "rice" , "dal", "mango", "rice", "chapati", "apple"}
lunch_b = {"rice" , "chapati", "pasta", "biryani"}

print(type(lunch_a))
print("lunch_a =", lunch_a)
print("lunch_b =", lunch_b)

#difference
print("lunch_a - lunch_b =", lunch_a - lunch_b)

#symm diff (uncommon)
print("lunch_a ^ lunch_b =", lunch_a ^ lunch_b)

