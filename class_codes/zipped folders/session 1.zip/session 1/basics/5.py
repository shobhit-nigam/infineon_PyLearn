# multiple assignments
# one

a = b = c = 33

print("a =", a)
print("b =", b)
