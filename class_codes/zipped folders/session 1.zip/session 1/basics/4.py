# int varx = 33;
varx = 33
print(type(varx))

vary = 45.7
print(type(vary))

varz = "star wars"
print(type(varz))

vary = "lucas"
print(type(vary))


help(vary.upper)
