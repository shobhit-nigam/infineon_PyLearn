# int varx = 33;
varx = 33
print(type(varx))

vary = 45.7
print(type(vary))

varz = "star wars"
print(type(varz))

import sys
print(sys.getsizeof(varx))
print(sys.getsizeof(varz))
