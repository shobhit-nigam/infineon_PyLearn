# immutable
# functions 
player = "rafael nadal"

print("player =", player)
print("player.upper() = ", player.upper())
print("player =", player)
