player = "nadal"

print("len of player =", len(player))
print("player[2] = ", player[2])

#error
print("player[7] = ", player[7])
