# slicing & stepping
player = "rafael nadal"

print("player[0:10] = ", player[0:10])
print("player[0:10:2] = ", player[0:10:2])
print("player[::-1] = ", player[::-1])
