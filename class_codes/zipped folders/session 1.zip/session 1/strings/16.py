# escape sequence 

vara = "Venkat loves \"idlis\""
print(vara)

city = "chennai\bengaluru"
print(city)
