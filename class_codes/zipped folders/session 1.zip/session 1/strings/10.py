# slicing
player = "rafael nadal"

print("player[0:9] = ", player[0:9])
print("player[:9] = ", player[:9])
print("player[4:11] = ", player[4:11])
print("player[4:] = ", player[4:])

print(player[:])
