# slicing
player = "nadal"

print("player[1] = ", player[1])

print("player[1:4] = ", player[1:4])
print("player[1:8] = ", player[1:8])
print("player[-4:-1] = ", player[-4:-1])
