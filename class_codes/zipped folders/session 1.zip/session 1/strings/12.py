# immutable
player = "rafael nadal"

print("player[2] = ", player[2])
# error 
player[2] = 'F'

#player = "djokovic"
