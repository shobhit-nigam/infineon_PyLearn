# 

vara = 3658
varb = "3658"
varc = "EDR5678T"
vard = "may the force be with you"

