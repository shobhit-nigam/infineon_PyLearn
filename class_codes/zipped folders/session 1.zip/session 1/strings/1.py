stat_a = "hello"
stat_b = 'world'

#error
#stat_c = "hello world'
