# slicing
player = "rafael nadal"

print("player[17:24] = ", player[17:24])

x = player[17:24]
print("type of x", type(x))
print("len of x", len(x))

