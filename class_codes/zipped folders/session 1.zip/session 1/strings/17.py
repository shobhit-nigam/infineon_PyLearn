# escape sequence 

vara = "sydney\new york"
print(vara)

vara = r"sydney\new york"
print(vara)



