stat_a = "Keya didn't have breakfast"


#error 
#stat_b = "Venkat love "idlis""

stat_b = 'Venkat love "idlis"'
print(stat_a)
print(stat_b)


