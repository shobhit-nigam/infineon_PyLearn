
avengers = ["thor", "ironman", "black widow", "captain"]

marvel = ["magneto", "moon knight", avengers]

print("avengers =", avengers)
avengers.reverse()
print("avengers =", avengers)
avengers.append("Hawkeye")
print("avengers =", avengers)
avengers.sort()
print("avengers =", avengers)
avengers.insert(3, "vision")
print("avengers =", avengers)
avengers.pop()
print("avengers =", avengers)
avengers.pop(1)
print("avengers =", avengers)
avengers.remove("vision")
print("avengers =", avengers)
