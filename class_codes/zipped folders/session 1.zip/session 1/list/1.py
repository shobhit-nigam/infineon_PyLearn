

players = ["federer", "nadal", "murray", "zverev", "djokovic"]
print("type of players =", type(players))
print("players =", players)
