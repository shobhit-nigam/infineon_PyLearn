
avengers = ["thor", "ironman", "black widow", "captain"]

marvel = ["magneto", "moon knight", "spiderman", avengers.copy()]

print("avengers =", avengers)
avengers.clear()
print("avengers =", avengers)



