
players = ["federer", "nadal", "murray", "zverev", "djokovic"]
print("type of players =", type(players))
print("players =", players)

num = [23, 6.7, 43, 89, 12, 65, 23]
print("type of num =", type(num))
print("num =", num)
