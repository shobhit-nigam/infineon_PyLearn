
avengers = ["thor", "ironman", "black widow", "captain"]

marvel = ["magneto", "moon knight", avengers]

print("marvel = ", marvel);
print("----")

print("marvel[0] =",marvel[0])
print("marvel[0][2] =",marvel[0][2])
print("----")

print("marvel[2] =",marvel[2])
print("marvel[2][1] =",marvel[2][1])
print("marvel[2][1][2] =",marvel[2][1][2])
