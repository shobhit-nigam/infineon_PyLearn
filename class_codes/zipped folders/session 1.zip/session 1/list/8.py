
avengers = ["thor", "ironman", "black widow", "captain"]

marvel = ["magneto", "moon knight", avengers]

print("marvel[1:3] = ", marvel[1:3])
print("----")
print("marvel[1:3][1] = ", marvel[1:3][1])
print("----")
print("marvel[1:3][1][1:3] = ", marvel[1:3][1][1:3])
