
avengers = ["thor", "ironman", "black widow", "captain"]

marvel = ["magneto", "moon knight", avengers]

print("marvel = ", marvel);

print("len of avengers = ", len(avengers))
print("len of marvel = ", len(marvel))
