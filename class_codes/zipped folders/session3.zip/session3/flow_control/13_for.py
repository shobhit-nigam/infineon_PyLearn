# for with sequence

lista = ["aa", "bb", "cc", "yy", "aa", "ee", "ll", "aa", "jj", "cc"]

for x in lista:
    print('x =', x)
    
