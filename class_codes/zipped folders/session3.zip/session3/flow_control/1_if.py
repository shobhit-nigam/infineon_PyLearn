# if else

data_a = 30
data_b = int(input())

if data_a > data_b :
    print("a is greater")
    # logic for the code
else:
    print("part under the else")
    print("b is greater")
    
print("outside the if-else code block")
    
