# if else

data_a = 30
data_b = int(input())

# if (data_a > data_b) and (data_b > 10):
# if data_a > data_b and data_b > 10:

if data_a > data_b > 10:
    print("a is greater")
    # logic for the code
    #####
elif data_a == data_b:
    pass
else:
    print("part under the else")
    print("b is greater")
    
print("outside the if-else code block")
    
