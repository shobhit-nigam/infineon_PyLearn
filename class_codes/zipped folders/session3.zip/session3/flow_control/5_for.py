# for

data_a = 30
#data_b = int(input())

for i in range(3, 9):
    print("i =", i)
    
