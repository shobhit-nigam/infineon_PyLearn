# for

for i in range(3, 7):
    print("i =", i)

print("----")

for i in range(7, 3, -1):
    print("i =", i)
    
print("----")

for i in range(3, 7, -1):
    print("i =", i)
    
