# for

lista = ["aa", "bb", "cc", "yy", "aa", "ee", "ll", "aa", "jj", "cc"]

for i in range(len(lista)):
    print("lista[i] =", lista[i])
    
