# while

data_a = 30
data_b = int(input())


while data_a > data_b:
    print("b is smaller, which is =", data_b)
    # logic for the code
    data_b = data_b + 1

    
print("outside the while code block")
    
