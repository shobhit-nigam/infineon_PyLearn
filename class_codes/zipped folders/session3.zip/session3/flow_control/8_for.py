# for

data_a = 30
#data_b = int(input())

for i in range(3):
    for j in range(3):
        print("i =", i, "j =", j)
    print("-----")
    
