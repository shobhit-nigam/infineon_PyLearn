lista = [10, 20]
listb = [10, 30]

seta = {"hello", lista, listb}

# seta = {"hello", [10, 20], [10, 30]}

lista[-1] = 30

# seta = {"hello", [10, 30], [10, 30]}
