# print
x=30
y=40
print(x,y, end=", ")
print("hello", end=", ")
print("nice dp", end=", ")
print("blocked")
