# define a function
# variable number of arguments

def greet(la, lb, *lc):
    print("la =", la)
    print("lb =", lb)
#    lb_x = lb[:3]
#    lb_y = lb[3:]
#    print("lbx =", lb_x)
#    print("lby =", lb_y)
    print("lc =", lc)

