# define a function
# return any number of values
# default return None

def greet(la, lb, lc):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

    


