print("welcome to colours")

def blue():
    print("cool blue")

def red():
    print("scarlet red")

def black():
    print("black is beautiful")

def purple():
    print("purple needs")
    blue()
    red()
