# define a function
# return any number of values
# default return None

def greet(la, lb, lc):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)
    return la+lb, lc-la, "hello", [3, 4, 7]

    

greet = 10
