# define a function
# default values to the right most

#error
def greet(la=55, lb, lc=66):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

