# define a function

def greet(la, lb):
    print("la =", la)
    print("lb =", lb)

print(type(greet))

x = greet
