# define a function
# default values

def greet(la, lb=55, lc=66):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

