# define a function

def greet():
    print("namaste")
    print("good morning")
print("outside the function")

greet()
