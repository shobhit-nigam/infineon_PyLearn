import colour

colour.blue()

# error
blue()
