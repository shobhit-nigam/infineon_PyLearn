from colour import blue

blue()
