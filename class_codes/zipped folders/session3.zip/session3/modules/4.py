import sys

#print(sys.path)

new_path = "/Users/shobhit/Desktop/infineon/session3/functions"

sys.path.append(new_path)

for p in sys.path:
    print(p)
