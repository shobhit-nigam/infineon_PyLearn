print("hungry yet ?")

from colour import blue, purple

print("hello world")


