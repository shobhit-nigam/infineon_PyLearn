#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os


# In[2]:


os.listdir()


# In[3]:


os.getcwd()


# In[4]:


os.mkdir("sample")


# In[5]:


os.path.exists("sample")


# In[6]:


os.path.isdir('sample')


# In[7]:


get_ipython().run_line_magic('pinfo', 'os.chmod')


# In[8]:


os.getcwd()


# In[9]:


os.chdir("..")


# In[10]:


os.getcwd()


# In[11]:


os.chdir("misc")


# In[12]:


os.getcwd()


# In[ ]:




