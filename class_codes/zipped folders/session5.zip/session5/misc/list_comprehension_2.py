listx = ["aa", "bb", "dd", "da", "ta", "at", "hy", "oa"]

listy = [val.upper() for val in listx]

print(listy)
