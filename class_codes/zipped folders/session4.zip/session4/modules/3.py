import new_colour

# ignored
import os

import importlib
importlib.reload(os)
