# namespace
if __name__ == "__main__":
    print("colour.py is actually an application")
else:
    print("colour has been imported")
    
    def blue():
        """bbbbb
        ffff"""
        pass
        
def green():
    pass


# print("printing from colour, name =", __name__)
