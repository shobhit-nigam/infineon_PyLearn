import os

def blue():
    """bbbbb
    ffff"""
    pass
        
def green():
    pass
