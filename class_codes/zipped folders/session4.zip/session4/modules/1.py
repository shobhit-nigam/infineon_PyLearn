import colour

# '__main__'
print(__name__)

# 'colour'
print(colour.__name__)
