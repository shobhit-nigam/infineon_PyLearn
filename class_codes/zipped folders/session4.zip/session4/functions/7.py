seta = (0, [], None, False, 23, '', 100)

print(tuple(filter(None, seta)))
