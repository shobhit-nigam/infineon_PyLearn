
name = "john doe"
age = 41
val = 56.893674987

print("name is", name, "and age is", age)

# newer f-strings

print(f"name is {name} and age is {age}")
