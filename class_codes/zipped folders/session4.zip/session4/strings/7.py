
lista = [20, 45, 60, 61]

for i in lista:
    i+2

"""this code is used
to launch missiles
and can be launched from any py file"""

# every line
# khsa
# add

lista.append(100)
