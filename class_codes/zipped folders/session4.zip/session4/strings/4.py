
name = "john doe"
age = 41
val = 56.893674987
dicta = {20:"ttt", 35:"ggg"}

print("name is", name, "and age is", age)

# newer f-strings

print(f"name is {name} and age is {age}")

print(f"name is {name} and age is {dicta[35]}")

print(f"name is {name} and age is {val:.4f}")

print(f"name is {name} and age is {val}")
