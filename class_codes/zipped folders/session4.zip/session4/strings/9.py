"""kbkfd
ef
fer
efrgerg
fergrgt"""


    
__doc__
