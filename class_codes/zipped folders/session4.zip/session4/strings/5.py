
name = "john doe"
age = 41
val = 56.893674987
dicta = {20:"ttt", 35:"ggg"}

stra = f"age is {age}"
print(stra)

round(val, 3)
