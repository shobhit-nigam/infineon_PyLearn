def funca(la=10, lb=20):
    """an unique function
    needs two data
    which also have default values"""
    la+lb
    lc = la/lb

    
