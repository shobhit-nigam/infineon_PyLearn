fa = open("books.txt", "r")
    

