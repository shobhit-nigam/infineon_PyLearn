stra = "john doe"
print(type(stra))

strb = b"jane doe"
print(type(strb))

strb = u"jane doe"
print(type(strb))

#ASCII
#UTF-8

#UTF-8


