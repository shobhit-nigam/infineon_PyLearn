stra = """there once was a ship
that put to sea
the name of the ship was
the Billy of Tea"""

print(stra)
