
name = "john doe"
age = 41
val = 56.893

print("name is", name, "and age is", age)

# basic formatting (older, c style)
print("name is %s and age is %d" %(name, age))
