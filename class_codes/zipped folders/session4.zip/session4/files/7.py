fa = open("new_books.txt", "w")
fa.write("good day\n")
fa.close()
